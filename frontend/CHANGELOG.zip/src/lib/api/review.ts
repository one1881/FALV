import { post } from './client';

export interface ReviewDocumentRequest {
  document_type?: string;
  contract_id?: number;
  document_db_id?: number;
  content: string;
  title?: string;
  context?: Record<string, any>;
}

export interface ReviewIssue {
  type: string;
  severity: 'high' | 'medium' | 'low' | string;
  clause?: string;
  /** 问题描述：这块有什么问题 */
  description: string;
  /** 风险理由/原因：为什么有问题、有什么风险 */
  reason?: string;
  /** 法律依据：引用的法条 / 条款依据 */
  legal_basis?: string;
  /** 修改建议：建议怎么改 */
  suggestion: string;
}

export interface ReviewDimension {
  score: number;
  level?: string;
  summary?: string;
  issues?: ReviewIssue[];
}

export interface ReviewDocumentResponse {
  review_status?: string;
  overall_score?: number;
  dimensions?: Record<string, ReviewDimension>;
  issues?: ReviewIssue[];
  suggestions?: string[];
  parsed_document?: Record<string, any>;
  agents_executed?: string[];
  skills_used?: string[];
  mcp_tools_used?: string[];
  execution_trace?: any[];
  [key: string]: any;
}

export async function reviewDocument(data: ReviewDocumentRequest): Promise<ReviewDocumentResponse> {
  return post<ReviewDocumentResponse>('/api/review/review-document', data);
}
