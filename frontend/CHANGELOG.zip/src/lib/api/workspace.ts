import { get, post } from './client';

export interface RiskOverview {
  status: string;
  total_contracts: number;
  high_risk_count: number;
  pending_review_count: number;
  approved_count: number;
  rejected_count: number;
  risk_distribution: Array<{ category: string; count: number }>;
  recent_contracts: any[];
  generated_at: string;
}

export async function getRiskOverview(): Promise<RiskOverview> {
  return get<RiskOverview>('/api/risk-overview');
}
