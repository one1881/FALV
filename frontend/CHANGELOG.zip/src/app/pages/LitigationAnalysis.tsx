import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router";
import { Scale, Download, ArrowLeft, ArrowRight, FolderOpen, Loader2, FileText, Gavel, MapPin, Swords, Target, Route, ListChecks } from "lucide-react";
import { getCaseAnalysis, getLitigationCases, downloadCaseDoc, type CaseAnalysisPayload, type LitigationCaseItem } from "../../lib/api/litigation";
import { LitigationStageBar, EmptyCaseHint } from "../../app/components/LitigationStageBar";
import { PageHeader } from "../components/PageHeader";
import { cn } from "../../lib/utils";

function str(v: any): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "object") return v.name || v.text || v.title || "";
  return String(v);
}

export function LitigationAnalysis() {
  const [searchParams] = useSearchParams();
  const caseId = searchParams.get("case_id") || "";

  const [cases, setCases] = useState<LitigationCaseItem[]>([]);
  const [activeCase, setActiveCase] = useState(caseId);
  const [payload, setPayload] = useState<CaseAnalysisPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getLitigationCases()
      .then((res) => {
        setCases(res.items || []);
        if (!activeCase && res.items?.length > 0) setActiveCase(res.items[0].case_id);
      })
      .catch(() => setCases([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!activeCase) {
      setPayload(null);
      return;
    }
    setLoading(true);
    setError("");
    getCaseAnalysis(activeCase)
      .then((data) => setPayload(data))
      .catch((e: any) => {
        setError(e?.message || "加载策略数据失败");
        setPayload(null);
      })
      .finally(() => setLoading(false));
  }, [activeCase]);

  const strategy = payload?.strategy || {};
  const cause = payload?.cause || {};
  const jurisdiction = payload?.jurisdiction || {};
  const ready = Object.keys(strategy).length > 0;

  // 证据力量分析：消费 evidence_catalog 里的 useful / evidence_level 标签
  const evidenceCatalog: any[] = Array.isArray(payload?.evidence_catalog) ? payload.evidence_catalog : [];
  const evidenceWithTags = evidenceCatalog.filter((e) => e.useful !== undefined && e.useful !== null);
  const eviFavorable = evidenceWithTags.filter((e) => e.useful === true).length;
  const eviUnfavorable = evidenceWithTags.filter((e) => e.useful === false).length;
  const eviPending = evidenceCatalog.length - evidenceWithTags.length;
  const eviCountByLevel = (lv: string) => evidenceCatalog.filter((e) => e.evidence_level === lv).length;
  const unfavorableItems = evidenceCatalog.filter((e) => e.useful === false);

  const blocks: Array<{ icon: any; title: string; items: string[] }> = [
    {
      icon: Gavel,
      title: "案由认定",
      items: [str(strategy.cause || cause.name || cause), str(cause.legal_basis || strategy.legal_basis)],
    },
    {
      icon: MapPin,
      title: "管辖法院",
      items: [str(jurisdiction.court || strategy.jurisdiction), str(jurisdiction.basis || jurisdiction.legal_basis)],
    },
    {
      icon: Target,
      title: "构成要件与举证",
      items: Array.isArray(strategy.element_proof)
        ? strategy.element_proof.map((x: any) => (typeof x === "string" ? x : `${str(x.element)}：${str(x.proof)}`))
        : [],
    },
    {
      icon: Swords,
      title: "争议焦点",
      items: Array.isArray(strategy.dispute_focus)
        ? strategy.dispute_focus.map(str)
        : Array.isArray(strategy.disputes)
          ? strategy.disputes.map(str)
          : [],
    },
    {
      icon: Route,
      title: "诉讼路径",
      items: Array.isArray(strategy.litigation_path) ? strategy.litigation_path.map(str) : [],
    },
    {
      icon: ListChecks,
      title: "下一步",
      items: Array.isArray(strategy.next_steps) ? strategy.next_steps.map(str) : [],
    },
  ].filter((b) => b.items.some(Boolean));

  return (
    <div className="max-w-7xl space-y-8 pb-32 pt-8">
      {/* Hero（中性色，符合去色定稿） */}
      <PageHeader title="诉讼策略" description="基于案件要素与证据情况，生成完整的诉讼策略书，供开庭前内部研判使用。" />

      <LitigationStageBar current={3} ready={ready} caseId={activeCase} />

      {cases.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-[1.5rem] border border-border bg-card/90 px-6 py-4 shadow-sm">
          <div className="flex items-center gap-2 text-xs font-black text-foreground">
            <FolderOpen className="h-4 w-4 text-primary" />
            当前案件
          </div>
          <select
            value={activeCase}
            onChange={(e) => setActiveCase(e.target.value)}
            className="rounded-full border border-border bg-background px-4 py-1.5 text-xs font-bold text-foreground outline-none focus:border-primary/50"
          >
            {cases.map((c) => (
              <option key={c.case_id} value={c.case_id}>
                {c.case_id} · {c.case_title || "未命名案件"}
              </option>
            ))}
          </select>
        </div>
      )}

      {error && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-bold text-amber-700">
          {error}（案件可能尚未归档，可先到「案件受理」完成归档）
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border bg-card/60 px-8 py-16 text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <div className="mt-4 text-sm font-black text-foreground">正在加载诉讼策略…</div>
        </div>
      ) : !activeCase ? (
        <EmptyCaseHint />
      ) : (
        <section className="space-y-5">
          {/* 证据力量分析（来自证据目录标签） */}
          {evidenceCatalog.length > 0 && (
            <div className="overflow-hidden rounded-[1.5rem] border border-border bg-card/90 shadow-sm">
              <div className="flex flex-wrap items-center gap-3 border-b border-border px-6 py-5">
                <div className="flex items-center gap-2">
                  <Scale className="h-4 w-4 text-primary" />
                  <div className="text-sm font-black text-foreground">证据力量分析</div>
                </div>
                <span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-black text-primary">
                  {evidenceCatalog.length} 项证据
                </span>
                <div className="ml-auto flex flex-wrap items-center gap-2">
                  <div className="flex flex-wrap gap-2 text-[10px] font-black">
                    <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-emerald-700">有利 {eviFavorable}</span>
                    <span className="rounded-full border border-rose-200 bg-rose-50 px-3 py-1 text-rose-700">不利 {eviUnfavorable}</span>
                    {eviPending > 0 && <span className="rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-slate-600">待定 {eviPending}</span>}
                    <span className="rounded-full border border-border bg-secondary px-3 py-1 text-muted-foreground">证明力 A {eviCountByLevel("A")} · B {eviCountByLevel("B")} · C {eviCountByLevel("C")}</span>
                  </div>
                  <Link
                    to={`/litigation/trial?case_id=${activeCase}`}
                    className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-[11px] font-black text-primary-foreground transition-opacity hover:opacity-90"
                  >
                    下一步：庭审准备 <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>

              <div className="divide-y divide-border">
                {evidenceCatalog.map((item: any, idx: number) => {
                  const lv = item.evidence_level;
                  return (
                    <div key={idx} className="flex flex-wrap items-center gap-3 px-6 py-3.5">
                      <span className="w-8 shrink-0 text-[11px] font-black text-muted-foreground">{String(item.evidence_no ?? idx + 1).padStart(2, "0")}</span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-black text-foreground">{item.evidence_name || item.file_name || item.name || "未命名证据"}</div>
                        <div className="mt-0.5 truncate text-[11px] font-bold leading-5 text-muted-foreground">
                          {item.proof_purpose || item.purpose || "—"}
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-1.5">
                        {item.useful !== undefined && item.useful !== null && (
                          <span
                            className={cn(
                              "rounded-full border px-2 py-0.5 text-[9px] font-black",
                              item.useful ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-rose-200 bg-rose-50 text-rose-700",
                            )}
                          >
                            {item.useful ? "有利" : "不利"}
                          </span>
                        )}
                        {lv && (
                          <span
                            className={cn(
                              "rounded-full border px-2 py-0.5 text-[9px] font-black",
                              lv === "A"
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : lv === "B"
                                ? "border-amber-200 bg-amber-50 text-amber-700"
                                : "border-slate-200 bg-slate-100 text-slate-600",
                            )}
                          >
                            证明力 {lv}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {unfavorableItems.length > 0 && (
                <div className="border-t border-border bg-rose-50/40 px-6 py-4">
                  <div className="text-[10px] font-black tracking-widest text-rose-700">⚠ 不利证据提示</div>
                  <div className="mt-1.5 text-xs font-bold leading-6 text-rose-900/80">
                    {unfavorableItems.map((e: any) => e.evidence_name || e.file_name || "未命名证据").join("、")}
                    —— 策略与庭审需重点准备应对方案。
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 策略书 article */}
          <div className="overflow-hidden rounded-[1.5rem] border border-border bg-card/90 shadow-sm">
            <div className="flex flex-wrap items-center gap-3 border-b border-border px-6 py-5">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                <div className="text-sm font-black text-foreground">诉讼策略书</div>
              </div>
              <span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-black text-primary">
                {payload?.case?.case_id || activeCase}
              </span>
              <div className="ml-auto flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => downloadCaseDoc(activeCase, "strategy", "03-诉讼策略书.md")}
                  className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 px-4 py-1.5 text-[11px] font-bold text-primary transition-colors hover:bg-accent"
                >
                  <Download className="h-3.5 w-3.5" /> 下载本件 .md
                </button>
                <Link
                  to={`/litigation/trial?case_id=${activeCase}`}
                  className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-[11px] font-black text-primary-foreground transition-opacity hover:opacity-90"
                >
                  下一步：庭审准备 <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>

            {blocks.length === 0 ? (
              <div className="flex flex-col items-center justify-center px-8 py-16 text-center">
                <FileText className="h-10 w-10 text-muted-foreground/50" />
                <div className="mt-4 text-sm font-black text-foreground">诉讼策略尚未生成</div>
                <div className="mt-2 max-w-md text-xs font-bold leading-6 text-muted-foreground">
                  完成受理分析与证据整理后，这里会生成完整的诉讼策略书。
                </div>
              </div>
            ) : (
              <div className="px-6 py-6 sm:px-8">
                {/* 策略主线 */}
                {str(strategy.strategy_summary) && (
                  <div className="mb-6 rounded-2xl border border-primary/20 bg-primary/5 px-6 py-5">
                    <div className="text-[10px] font-black tracking-[0.24em] text-primary">总体策略</div>
                    <div className="mt-2 text-sm font-black leading-7 text-foreground">{str(strategy.strategy_summary)}</div>
                  </div>
                )}

                <div className="grid gap-4 md:grid-cols-2">
                  {blocks.map((block, idx) => (
                    <div key={idx} className="rounded-2xl border border-border bg-card p-5">
                      <div className="flex items-center gap-2">
                        <block.icon className="h-4 w-4 text-primary" />
                        <div className="text-xs font-black text-foreground">{block.title}</div>
                      </div>
                      <div className="mt-3 space-y-2">
                        {block.items.map((item, i) => (
                          <div key={i} className="rounded-xl bg-muted/60 px-4 py-2.5 text-xs font-bold leading-6 text-muted-foreground">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 rounded-2xl bg-muted/60 px-6 py-4 text-[11px] font-bold leading-6 text-muted-foreground">
                  说明：本策略书由 AI 基于案件要素与已确认证据生成，仅供律师内部研判参考，最终以承办律师意见为准。
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* 流程导航（始终可见，避免迷路） */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-[1.5rem] border border-border bg-card/90 px-6 py-4 shadow-sm">
        <Link
          to={`/litigation/evidence?case_id=${activeCase}`}
          className="inline-flex items-center gap-1.5 rounded-full border border-border px-5 py-2.5 text-xs font-black text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> 上一步：证据目录
        </Link>
        <div className="flex items-center gap-2 text-[11px] font-black text-muted-foreground">
          <span className="rounded-full bg-secondary px-3 py-1">第 3 步 / 共 5 步</span>
        </div>
        <Link
          to={`/litigation/trial?case_id=${activeCase}`}
          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-5 py-2.5 text-xs font-black text-primary-foreground shadow-sm transition-opacity hover:opacity-90"
        >
          下一步：庭审准备 <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}
