import { useEffect, useState } from "react";
import { useSearchParams } from "react-router";
import { Download, FolderOpen, Loader2, FileText, MessageSquare, ShieldCheck, Mic2, HelpCircle } from "lucide-react";
import { getCaseTrial, getLitigationCases, downloadCaseDoc, type CaseStagePayload, type LitigationCaseItem } from "../../lib/api/litigation";
import { LitigationStageBar, EmptyCaseHint } from "../../app/components/LitigationStageBar";
import { PageHeader } from "../components/PageHeader";

const DOCS = [
  {
    key: "questionnaire",
    title: "发问提纲",
    desc: "围绕案件争议焦点，梳理开庭时向对方当事人 / 证人发问的问题清单",
    file: "04-发问提纲.md",
    icon: MessageSquare,
    placeholder: ["1. 2026 年 3 月 15 日借款 20 万元是否属实？", "2. 双方对利息（年化 12%）是否有书面约定？", "3. 承诺的还款时间与已还金额是多少？"],
  },
  {
    key: "cross_examination",
    title: "质证提纲",
    desc: "对每份证据从真实性、合法性、关联性、证明力四个维度逐项质证",
    file: "05-质证提纲.md",
    icon: ShieldCheck,
    placeholder: ["真实性：对证据形成过程、原始载体有无异议", "合法性：取证手段与来源是否合法", "关联性：与待证事实的关联程度", "证明力：能否达到高度盖然性标准"],
  },
  {
    key: "closing",
    title: "法庭辩论词",
    desc: "四段式辩论词：事实陈述 → 法律适用 → 证据分析 → 请求结论",
    file: "06-法庭辩论词.md",
    icon: Mic2,
    placeholder: ["一、关于本案基本事实", "二、关于法律适用", "三、关于证据认定", "四、关于诉讼请求"],
  },
  {
    key: "judge_qa",
    title: "法官高频问答",
    desc: "预演法官可能询问的问题与应答要点，开庭不慌",
    file: "07-法官问答.md",
    icon: HelpCircle,
    placeholder: ["问：借款是否已实际交付？", "问：有无书面借款凭证？", "问：对方是否主张已还款？"],
  },
];

function unwrap(payload: CaseStagePayload | null): any {
  if (!payload) return {};
  const inner = payload.payload;
  if (inner && typeof inner === "object") return inner;
  return payload;
}

function sectionText(data: any, key: string): string {
  const v = data?.[key];
  if (!v) return "";
  if (typeof v === "string") return v;
  if (Array.isArray(v)) return v.join("\n");
  return JSON.stringify(v, null, 2);
}

export function LitigationTrialOutline() {
  const [searchParams] = useSearchParams();
  const caseId = searchParams.get("case_id") || "";

  const [cases, setCases] = useState<LitigationCaseItem[]>([]);
  const [activeCase, setActiveCase] = useState(caseId);
  const [payload, setPayload] = useState<CaseStagePayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getLitigationCases()
      .then((res) => {
        setCases(res.items || []);
        if (!activeCase && res.items?.length > 0) setActiveCase(res.items[0].case_id);
      })
      .catch(() => setCases([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!activeCase) {
      setPayload(null);
      return;
    }
    setLoading(true);
    setError("");
    getCaseTrial(activeCase)
      .then((data) => setPayload(data))
      .catch((e: any) => {
        setError(e?.message || "加载庭审数据失败");
        setPayload(null);
      })
      .finally(() => setLoading(false));
  }, [activeCase]);

  const data = unwrap(payload);
  const ready = Object.keys(data).length > 0;

  return (
    <div className="max-w-7xl space-y-8 pb-32 pt-8">
      {/* Hero（中性色） */}
      <PageHeader title="庭审准备" description="开庭前的四件套：发问提纲、质证提纲、法庭辩论词、法官高频问答，逐件下载备用。" />

      <LitigationStageBar current={4} ready={ready} caseId={activeCase} />

      {cases.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-[1.5rem] border border-border bg-card/90 px-6 py-4 shadow-sm">
          <div className="flex items-center gap-2 text-xs font-black text-foreground">
            <FolderOpen className="h-4 w-4 text-primary" />
            当前案件
          </div>
          <select
            value={activeCase}
            onChange={(e) => setActiveCase(e.target.value)}
            className="rounded-full border border-border bg-background px-4 py-1.5 text-xs font-bold text-foreground outline-none focus:border-primary/50"
          >
            {cases.map((c) => (
              <option key={c.case_id} value={c.case_id}>
                {c.case_id} · {c.case_title || "未命名案件"}
              </option>
            ))}
          </select>
        </div>
      )}

      {error && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-bold text-amber-700">
          {error}（案件可能尚未归档，可先到「案件受理」完成归档）
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border bg-card/60 px-8 py-16 text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <div className="mt-4 text-sm font-black text-foreground">正在加载庭审文书…</div>
        </div>
      ) : !activeCase ? (
        <EmptyCaseHint />
      ) : (
        <div className="space-y-6">
          {DOCS.map((doc) => {
            const content = sectionText(data, doc.key);
            return (
              <article key={doc.key} className="overflow-hidden rounded-[1.5rem] border border-border bg-card/90 shadow-sm">
                <div className="flex flex-wrap items-center gap-3 border-b border-border px-6 py-5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <doc.icon className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-sm font-black text-foreground">{doc.title}</div>
                    <div className="mt-0.5 text-[11px] font-bold text-muted-foreground">{doc.desc}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => downloadCaseDoc(activeCase, doc.key === "cross_examination" ? "cross-exam" : doc.key, doc.file)}
                    className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-primary/40 px-4 py-1.5 text-[11px] font-bold text-primary transition-colors hover:bg-accent"
                  >
                    <Download className="h-3.5 w-3.5" /> 下载本件 .md
                  </button>
                </div>

                <div className="px-6 py-6 sm:px-8">
                  {content ? (
                    <div className="whitespace-pre-wrap rounded-2xl bg-muted/60 px-5 py-4 text-xs font-bold leading-7 text-foreground/90">
                      {content}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="text-[11px] font-bold text-muted-foreground">
                        「{doc.title}」尚未生成，可先参考以下框架，归档并完成策略分析后自动填充。
                      </div>
                      <div className="rounded-2xl border border-dashed border-border px-5 py-4">
                        {doc.placeholder.map((line, i) => (
                          <div key={i} className="flex items-start gap-2 py-1.5 text-xs font-bold leading-6 text-muted-foreground">
                            <FileText className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-primary/50" />
                            {line}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
