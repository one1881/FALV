import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router";
import { Download, FolderOpen, Loader2, FileArchive, CheckCircle2, FileText, Table2, FolderTree, Archive } from "lucide-react";
import {
  getCasePackage,
  getLitigationCases,
  downloadCaseDoc,
  downloadCasePackageZip,
  type CaseStagePayload,
  type LitigationCaseItem,
} from "../../lib/api/litigation";
import { LitigationStageBar, EmptyCaseHint } from "../../app/components/LitigationStageBar";
import { PageHeader } from "../components/PageHeader";

interface Artifact {
  name: string;
  desc: string;
  doc?: string; // 后端导出端点 key（无则随 ZIP）
  kind: "md" | "csv" | "auto";
}

const ARTIFACTS: Artifact[] = [
  { name: "00-案件总览.md", desc: "案件编号、当事人、诉求与整体进展一览", kind: "md" },
  { name: "01-证据册封面.md", desc: "法院提交版证据册封面", kind: "md", doc: "cover" },
  { name: "02-证据目录.md", desc: "法院提交格式证据目录", kind: "md", doc: "evidence-catalog" },
  { name: "02-证据目录.csv", desc: "证据目录表格版（Excel 可打开）", kind: "csv" },
  { name: "03-诉讼策略书.md", desc: "案由、管辖、要件举证、争议焦点、诉讼路径", kind: "md", doc: "strategy" },
  { name: "04-发问提纲.md", desc: "开庭发问问题清单", kind: "md", doc: "questionnaire" },
  { name: "05-质证提纲.md", desc: "四维度质证：真实性 / 合法性 / 关联性 / 证明力", kind: "md", doc: "cross-exam" },
  { name: "06-法庭辩论词.md", desc: "四段式完整辩论词，附代理人签字栏", kind: "md", doc: "closing" },
  { name: "07-法官问答.md", desc: "法官高频问答与应答要点", kind: "md", doc: "judge-qa" },
  { name: "08-开庭公文包清单.md", desc: "开庭出门前逐项核对清单", kind: "md", doc: "court-brief" },
  { name: "05-原始材料/", desc: "原始图片 / 音视频 / 文档原件，自动随包", kind: "auto" },
];

const CHECKLIST = [
  "起诉状 / 答辩状原件与副本",
  "证据册（目录 + 证据 + 页码）",
  "授权委托书与所函",
  "律师证 / 执业证原件",
  "传票、出庭通知书",
  "当事人身份证明 / 营业执照",
];

export function LitigationPackage() {
  const [searchParams] = useSearchParams();
  const caseId = searchParams.get("case_id") || "";

  const [cases, setCases] = useState<LitigationCaseItem[]>([]);
  const [activeCase, setActiveCase] = useState(caseId);
  const [payload, setPayload] = useState<CaseStagePayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [checked, setChecked] = useState<Set<number>>(new Set());
  const [zipping, setZipping] = useState(false);

  useEffect(() => {
    getLitigationCases()
      .then((res) => {
        setCases(res.items || []);
        if (!activeCase && res.items?.length > 0) setActiveCase(res.items[0].case_id);
      })
      .catch(() => setCases([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!activeCase) {
      setPayload(null);
      return;
    }
    setLoading(true);
    setError("");
    getCasePackage(activeCase)
      .then((data) => setPayload(data))
      .catch((e: any) => {
        setError(e?.message || "加载材料包失败");
        setPayload(null);
      })
      .finally(() => setLoading(false));
  }, [activeCase]);

  // 完成度：材料包 payload 存在且有内容视为已打包
  const hasPayload = useMemo(() => {
    if (!payload) return false;
    const inner = payload.payload;
    return Object.keys(inner && typeof inner === "object" ? inner : payload).length > 0;
  }, [payload]);

  const readyCount = hasPayload ? ARTIFACTS.length : 0;
  const percent = hasPayload ? 100 : Math.min(ARTIFACTS.length, Math.max(0, readyCount)) * 0;

  const handleZip = () => {
    if (!activeCase) return;
    setZipping(true);
    downloadCasePackageZip(activeCase);
    setTimeout(() => setZipping(false), 1500);
  };

  const toggleCheck = (idx: number) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  return (
    <div className="max-w-7xl space-y-8 pb-32 pt-8">
      {/* Hero（中性色） */}
      <PageHeader title="材料包" description="前序环节产出的全部文书自动汇总于此，一键打包下载，开庭前逐件核对。" />

      <LitigationStageBar current={5} ready={hasPayload} caseId={activeCase} />

      {cases.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-[1.5rem] border border-border bg-card/90 px-6 py-4 shadow-sm">
          <div className="flex items-center gap-2 text-xs font-black text-foreground">
            <FolderOpen className="h-4 w-4 text-primary" />
            当前案件
          </div>
          <select
            value={activeCase}
            onChange={(e) => setActiveCase(e.target.value)}
            className="rounded-full border border-border bg-background px-4 py-1.5 text-xs font-bold text-foreground outline-none focus:border-primary/50"
          >
            {cases.map((c) => (
              <option key={c.case_id} value={c.case_id}>
                {c.case_id} · {c.case_title || "未命名案件"}
              </option>
            ))}
          </select>
        </div>
      )}

      {error && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-bold text-amber-700">
          {error}（案件可能尚未归档，可先到「案件受理」完成归档）
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border bg-card/60 px-8 py-16 text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <div className="mt-4 text-sm font-black text-foreground">正在加载材料包…</div>
        </div>
      ) : !activeCase ? (
        <EmptyCaseHint />
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          {/* 主区：成品列表 */}
          <section className="space-y-4">
            <div className="rounded-[1.5rem] border border-border bg-card/90 p-6 shadow-sm">
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileArchive className="h-4 w-4 text-primary" />
                  <div className="text-sm font-black text-foreground">材料包成果物（{ARTIFACTS.length} 件）</div>
                </div>
                <span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-black text-primary">
                  {activeCase}
                </span>
              </div>

              <div className="space-y-3">
                {ARTIFACTS.map((art, idx) => (
                  <div
                    key={art.name}
                    className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5 transition-colors hover:border-primary/30 hover:bg-accent/30"
                  >
                    <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      {art.kind === "csv" ? <Table2 className="h-4 w-4" /> : art.kind === "auto" ? <FolderTree className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <div className="truncate text-xs font-black text-foreground">{art.name}</div>
                        {art.kind === "auto" && (
                          <span className="rounded-full bg-muted px-2 py-0.5 text-[9px] font-bold text-muted-foreground">自动</span>
                        )}
                      </div>
                      <div className="mt-0.5 truncate text-[11px] font-bold text-muted-foreground">{art.desc}</div>
                    </div>
                    {art.doc ? (
                      <button
                        type="button"
                        onClick={() => downloadCaseDoc(activeCase, art.doc!, art.name)}
                        className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 px-3.5 py-1.5 text-[11px] font-bold text-primary transition-colors hover:bg-accent"
                      >
                        <Download className="h-3.5 w-3.5" /> 下载
                      </button>
                    ) : (
                      <span className="rounded-full bg-muted px-3.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                        随 ZIP 打包
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 侧栏：打包 + 出门清单 */}
          <aside className="space-y-5">
            <div className="rounded-[1.5rem] border border-border bg-card/90 p-6 shadow-sm lg:sticky lg:top-6">
              <div className="text-sm font-black text-foreground">打包中心</div>

              {/* 完成度 */}
              <div className="mt-5 flex items-end justify-between">
                <div>
                  <div className="text-3xl font-black text-foreground">{percent}%</div>
                  <div className="text-[10px] font-bold tracking-widest text-muted-foreground">材料包完成度</div>
                </div>
                <div className="text-right text-[10px] font-bold leading-5 text-muted-foreground">
                  {hasPayload ? "全部成果物已就绪" : "完成前序环节后自动生成"}
                </div>
              </div>
              <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${percent}%` }} />
              </div>

              {/* 一键打包 */}
              <button
                type="button"
                onClick={handleZip}
                disabled={zipping || !hasPayload}
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-6 py-4 text-sm font-black text-primary-foreground shadow-md transition-all hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {zipping ? <Loader2 className="h-5 w-5 animate-spin" /> : <Archive className="h-5 w-5" />}
                一键打包下载 ZIP
              </button>
              <div className="mt-3 text-center text-[10px] font-bold text-muted-foreground">
                包含全部文书 + 原始材料，按案件编号分目录
              </div>

              {/* 出门前对照清单 */}
              <div className="mt-6 border-t border-border pt-5">
                <div className="mb-3 text-[10px] font-black tracking-[0.24em] text-muted-foreground">出门前对照清单</div>
                <div className="space-y-1.5">
                  {CHECKLIST.map((item, idx) => {
                    const done = checked.has(idx);
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => toggleCheck(idx)}
                        className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[11px] font-bold transition-colors hover:bg-accent/50"
                      >
                        <span
                          className={
                            done
                              ? "flex h-4 w-4 items-center justify-center rounded-md bg-primary text-primary-foreground"
                              : "flex h-4 w-4 items-center justify-center rounded-md border border-border bg-background"
                          }
                        >
                          {done && <CheckCircle2 className="h-3 w-3" />}
                        </span>
                        <span className={done ? "text-muted-foreground line-through" : "text-foreground"}>{item}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
