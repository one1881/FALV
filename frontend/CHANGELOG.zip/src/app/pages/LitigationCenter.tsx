import { Link } from "react-router";
import { Scale, ShieldCheck, Target, Mic2, Package } from "lucide-react";
import { PageHeader } from "../components/PageHeader";

const actions = [
  {
    icon: Scale,
    title: "案件受理",
    description: "上传案件材料文件夹，AI 识别后律师确认，生成受理分析。",
    to: "/litigation/new",
  },
  {
    icon: ShieldCheck,
    title: "证据管理",
    description: "查看法院提交格式的证据目录，按类补全标准证据模板。",
    to: "/litigation/evidence",
  },
  {
    icon: Target,
    title: "诉讼策略",
    description: "生成案由、管辖、要件举证、争议焦点与诉讼路径策略书。",
    to: "/litigation/analysis",
  },
  {
    icon: Mic2,
    title: "庭审准备",
    description: "发问提纲、质证提纲、法庭辩论词、法官高频问答四件套。",
    to: "/litigation/trial",
  },
  {
    icon: Package,
    title: "材料包",
    description: "前序环节成果物自动汇总，一键打包下载，出门前逐件核对。",
    to: "/litigation/package",
  },
];

export function LitigationCenter() {
  return (
    <div className="max-w-7xl space-y-8 pb-20 pt-8">
      <PageHeader
        title="诉讼中心"
        description="从受理、证据、策略、庭审到材料包的五步流水线，每步产出一份可用的律师成果物。"
      />

      <section className="grid gap-5 md:grid-cols-2">
        {actions.map((item) => (
          <Link
            key={item.title}
            to={item.to}
            className="rounded-[1.5rem] border border-border bg-card p-6 shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
          >
            <item.icon className="h-5 w-5 text-primary" />
            <div className="mt-4 text-sm font-black text-foreground">{item.title}</div>
            <div className="mt-2 text-xs font-bold text-muted-foreground">{item.description}</div>
          </Link>
        ))}
      </section>
    </div>
  );
}
