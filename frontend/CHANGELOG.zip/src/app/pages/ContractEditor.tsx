import { useEffect, useRef, useState } from "react";
import { useParams, useSearchParams } from "react-router";
import {
  Save,
  FileType2,
  FileDown,
  CheckCircle,
  Loader2,
  AlertTriangle,
  Edit3,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Type,
  ChevronDown,
  X,
  ShieldCheck,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { getContract, updateContract, type ContractDetail } from "../../lib/api/contracts";
import { reviewDocument, type ReviewDocumentResponse, type ReviewIssue } from "../../lib/api/review";

export function ContractEditor() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const initialType = searchParams.get("type") || "";

  const editorRef = useRef<HTMLDivElement>(null);
  const syncedRef = useRef(false);
  const [contract, setContract] = useState<ContractDetail | null>(null);
  const [title, setTitle] = useState("");
  const [html, setHtml] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [reviewing, setReviewing] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewResult, setReviewResult] = useState<ReviewDocumentResponse | null>(null);
  const [activeReviewIssue, setActiveReviewIssue] = useState<number | null>(null);
  const [fontSize, setFontSize] = useState("16px");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    syncedRef.current = false;
    setContract(null);
    setHtml("");
    setError("");
    setMessage("");
    setReviewResult(null);
    setReviewOpen(false);
    const load = async () => {
      try {
        const data = await getContract(Number(id));
        setContract(data);
        setTitle(data.title || initialType || "未命名合同");
        const content = data.html_content || data.content || "";
        setHtml(content);
      } catch (err: any) {
        setError(err?.message || "加载合同失败");
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, [id, initialType]);

  // 加载完成且编辑器 DOM 已挂载后，把正文同步到编辑器（仅同步一次，避免覆盖用户输入）
  useEffect(() => {
    if (syncedRef.current) return;
    if (loading) return;
    if (!editorRef.current) return;
    editorRef.current.innerHTML = html || "";
    syncedRef.current = true;
  }, [loading, html]);

  const execCommand = (command: string, value: string | undefined = undefined) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    syncHtml();
  };

  const syncHtml = () => {
    if (editorRef.current) {
      setHtml(editorRef.current.innerHTML);
    }
  };

  const handleSave = async () => {
    if (!contract) return;
    setSaving(true);
    try {
      const content = editorRef.current?.innerHTML || html;
      await updateContract(contract.id, { title, content });
      setMessage("保存成功");
      setTimeout(() => setMessage(""), 2000);
    } catch (err: any) {
      setError(err?.message || "保存失败");
    } finally {
      setSaving(false);
    }
  };

  const downloadWord = () => {
    const content = editorRef.current?.innerHTML || html;
    const htmlDoc = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${title}</title></head><body>${content}</body></html>`;
    const blob = new Blob(["\ufeff" + htmlDoc], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title || "合同"}.doc`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadPdf = () => {
    const content = editorRef.current?.innerHTML || html;
    const htmlDoc = `<html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:'PingFang SC','Microsoft YaHei',sans-serif;font-size:14px;line-height:1.8;color:#111;padding:48px;} h1{text-align:center;font-size:22px;margin-bottom:24px;} p{text-indent:2em;margin:8px 0;}</style></head><body>${content}</body></html>`;
    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "0";
    iframe.style.bottom = "0";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "0";
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow?.document;
    doc?.open();
    doc?.write(htmlDoc);
    doc?.close();
    window.setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      window.setTimeout(() => document.body.removeChild(iframe), 1000);
    }, 200);
  };

  const handleReview = async () => {
    if (!contract) return;
    const content = editorRef.current?.innerText || editorRef.current?.innerHTML || html;
    setReviewing(true);
    setError("");
    try {
      const result = await reviewDocument({
        contract_id: contract.id,
        document_type: contract.contract_type || "contract",
        content,
        title,
      });
      setReviewResult(result);
      setReviewOpen(true);
    } catch (err: any) {
      setError(err?.message || "条款审查失败");
    } finally {
      setReviewing(false);
    }
  };

  const updateReviewIssue = (idx: number, patch: Partial<ReviewIssue>) => {
    if (!reviewResult) return;
    const next = { ...reviewResult };
    const issues = [...(next.issues || [])];
    issues[idx] = { ...issues[idx], ...patch };
    next.issues = issues;
    setReviewResult(next);
  };

  const removeReviewIssue = (idx: number) => {
    if (!reviewResult) return;
    const next = { ...reviewResult };
    next.issues = (next.issues || []).filter((_, i) => i !== idx);
    setReviewResult(next);
    if (activeReviewIssue === idx) setActiveReviewIssue(null);
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center pb-20 pt-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const allIssues = reviewResult?.issues || [];
  const overallScore = reviewResult?.overall_score ?? reviewResult?.dimensions?.overall?.score;
  const reviewStatus = reviewResult?.review_status || "pass";
  const statusMeta =
    reviewStatus === "pass" || reviewStatus === "approved"
      ? { label: "已通过", cls: "bg-emerald-50 text-emerald-700 border-emerald-200" }
      : reviewStatus === "warning" || reviewStatus === "needs_revision"
      ? { label: "需修改", cls: "bg-amber-50 text-amber-700 border-amber-200" }
      : { label: "审核完成", cls: "bg-sky-50 text-sky-700 border-sky-200" };

  return (
    <div className="flex h-[calc(100vh-64px)] flex-col">
      {/* Top bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border bg-card px-6 py-3">
        <div className="flex items-center gap-3 min-w-0">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="min-w-[200px] max-w-md border-none bg-transparent text-lg font-black text-foreground outline-none placeholder:text-muted-foreground"
            placeholder="合同标题"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-xs font-black text-primary-foreground shadow-sm hover:opacity-90 disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            保存合同
          </button>
          <button
            onClick={downloadWord}
            className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2 text-xs font-black text-foreground transition-colors hover:bg-accent"
          >
            <FileType2 className="h-3.5 w-3.5" /> 下载 Word
          </button>
          <button
            onClick={downloadPdf}
            className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2 text-xs font-black text-foreground transition-colors hover:bg-accent"
          >
            <FileDown className="h-3.5 w-3.5" /> 下载 PDF
          </button>
          <button
            onClick={() => void handleReview()}
            disabled={reviewing}
            className="inline-flex items-center gap-1.5 rounded-xl border border-primary/30 bg-primary/10 px-4 py-2 text-xs font-black text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
          >
            {reviewing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldCheck className="h-3.5 w-3.5" />}
            送去条款审查
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border bg-secondary/30 px-6 py-2">
        <span className="text-xs font-bold text-muted-foreground">正文</span>
        <div className="h-4 w-px bg-border" />
        <div className="relative">
          <select
            value={fontSize}
            onChange={(e) => {
              setFontSize(e.target.value);
              execCommand("fontSize", e.target.value);
            }}
            className="h-8 appearance-none rounded-lg border border-border bg-card pl-2 pr-6 text-xs font-bold text-foreground outline-none focus:border-primary/40"
          >
            <option value="12px">12px</option>
            <option value="14px">14px</option>
            <option value="16px">16px</option>
            <option value="18px">18px</option>
            <option value="20px">20px</option>
            <option value="24px">24px</option>
          </select>
          <ChevronDown className="absolute right-1.5 top-1/2 h-3 w-3 -translate-y-1/2 text-muted-foreground pointer-events-none" />
        </div>
        <div className="h-4 w-px bg-border" />
        <ToolButton onClick={() => execCommand("bold")} label="加粗" icon={Bold} />
        <ToolButton onClick={() => execCommand("italic")} label="斜体" icon={Italic} />
        <ToolButton onClick={() => execCommand("underline")} label="下划线" icon={Underline} />
        <ToolButton onClick={() => execCommand("strikeThrough")} label="删除线" icon={Strikethrough} />
        <div className="h-4 w-px bg-border" />
        <ToolButton onClick={() => execCommand("justifyLeft")} label="左对齐" icon={AlignLeft} />
        <ToolButton onClick={() => execCommand("justifyCenter")} label="居中对齐" icon={AlignCenter} />
        <ToolButton onClick={() => execCommand("justifyRight")} label="右对齐" icon={AlignRight} />
        <div className="h-4 w-px bg-border" />
        <ToolButton onClick={() => execCommand("insertUnorderedList")} label="无序列表" icon={List} />
        <ToolButton onClick={() => execCommand("insertOrderedList")} label="有序列表" icon={ListOrdered} />
      </div>

      {/* Messages */}
      {message && (
        <div className="mx-6 mt-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700">
          <CheckCircle className="mr-1.5 inline-block h-3.5 w-3.5" /> {message}
        </div>
      )}
      {error && (
        <div className="mx-6 mt-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2 text-xs font-bold text-rose-700">
          <AlertTriangle className="mr-1.5 inline-block h-3.5 w-3.5" /> {error}
        </div>
      )}

      {/* Editor + review panel */}
      <div className="flex flex-1 overflow-hidden">
        <div className="flex flex-1 flex-col overflow-hidden">
          <div className="flex-1 overflow-auto bg-secondary/20 p-8">
            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={syncHtml}
              className="min-h-[800px] w-full max-w-4xl mx-auto rounded-[1.5rem] border border-border bg-card px-10 py-12 text-sm leading-7 text-foreground shadow-sm outline-none focus:ring-2 focus:ring-primary/10"
              style={{ fontFamily: "'PingFang SC','Microsoft YaHei',sans-serif", whiteSpace: "pre-wrap" }}
            />
          </div>
        </div>

        {reviewOpen && (
          <div className="w-[380px] flex-shrink-0 overflow-y-auto border-l border-border bg-card p-5 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-black text-foreground">条款审查结果</h3>
              <button onClick={() => setReviewOpen(false)} className="rounded-full p-1 text-muted-foreground hover:bg-accent">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className={cn("mb-4 rounded-2xl border px-4 py-3", statusMeta.cls)}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold">审核状态</span>
                <span className="text-xs font-black">{statusMeta.label}</span>
              </div>
              {overallScore !== undefined && (
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs font-bold">综合评分</span>
                  <span className="text-lg font-black">{overallScore}</span>
                </div>
              )}
            </div>

            <div className="space-y-3">
              {allIssues.length === 0 && (
                <div className="rounded-xl border border-border bg-secondary/30 px-4 py-6 text-center text-xs font-bold text-muted-foreground">
                  暂未发现问题
                </div>
              )}
              {allIssues.map((issue, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "rounded-2xl border p-4 transition-colors",
                    activeReviewIssue === idx ? "border-primary bg-primary/5" : "border-border bg-card hover:bg-accent/40"
                  )}
                  onClick={() => setActiveReviewIssue(idx)}
                >
                  <div className="mb-2 flex items-start justify-between gap-2">
                    <span
                      className={cn(
                        "rounded-full border px-2 py-0.5 text-[10px] font-black",
                        issue.severity === "high"
                          ? "bg-red-500 text-white border-red-600"
                          : issue.severity === "medium"
                          ? "bg-amber-500 text-white border-amber-600"
                          : "bg-slate-200 text-slate-700 border-slate-400"
                      )}
                    >
                      {issue.severity === "high" ? "高风险" : issue.severity === "medium" ? "中风险" : "提示"}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeReviewIssue(idx);
                      }}
                      className="text-muted-foreground hover:text-rose-600"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="mb-2 text-xs font-bold text-foreground">
                    <Edit3 className="mr-1 inline-block h-3 w-3 text-muted-foreground" />
                    <input
                      value={issue.clause || ""}
                      onChange={(e) => updateReviewIssue(idx, { clause: e.target.value })}
                      placeholder="条款"
                      className="w-full border-b border-transparent bg-transparent font-bold outline-none focus:border-primary"
                    />
                  </div>
                  <textarea
                    value={issue.description}
                    onChange={(e) => updateReviewIssue(idx, { description: e.target.value })}
                    rows={2}
                    className="mb-2 w-full resize-none rounded-lg border border-border bg-secondary/30 px-2 py-1 text-xs font-medium text-foreground outline-none focus:border-primary/40"
                  />
                  <textarea
                    value={issue.suggestion}
                    onChange={(e) => updateReviewIssue(idx, { suggestion: e.target.value })}
                    rows={2}
                    className="w-full resize-none rounded-lg border border-orange-300 bg-orange-50/60 px-2 py-1 text-xs font-medium text-orange-950 outline-none focus:border-orange-500"
                    placeholder="修改建议"
                  />
                </div>
              ))}
            </div>

            {reviewResult?.suggestions && reviewResult.suggestions.length > 0 && (
              <div className="mt-5 rounded-2xl border border-border bg-secondary/30 p-4">
                <h4 className="mb-2 text-xs font-black text-foreground">优化建议</h4>
                <ul className="list-disc space-y-1 pl-4 text-xs font-medium text-muted-foreground">
                  {reviewResult.suggestions.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ToolButton({ onClick, icon: Icon, label }: { onClick: () => void; icon: React.ElementType; label: string }) {
  return (
    <button
      onClick={onClick}
      title={label}
      className="flex h-8 w-8 items-center justify-center rounded-lg border border-transparent text-muted-foreground transition-colors hover:border-border hover:bg-card hover:text-foreground"
    >
      <Icon className="h-3.5 w-3.5" />
    </button>
  );
}
