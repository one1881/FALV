import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import {
  Upload,
  FileText,
  ShieldCheck,
  Loader2,
  AlertTriangle,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { reviewDocument, type ReviewDocumentResponse } from "../../lib/api/review";
import { TaskProgress } from "../../app/components/TaskProgress";
import { PageHeader } from "../components/PageHeader";

const ACCEPT_TYPES = ".txt,.doc,.docx,.pdf";

export function Approvals() {
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState("");
  const [content, setContent] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [reviewing, setReviewing] = useState(false);
  const [reviewStartedAt, setReviewStartedAt] = useState(0);
  const [error, setError] = useState("");

  const readTextFile = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error("读取文件失败"));
      reader.readAsText(file);
    });
  };

  const handleFile = async (file: File) => {
    setError("");
    if (
      !file.name.endsWith(".txt") &&
      !file.name.endsWith(".doc") &&
      !file.name.endsWith(".docx") &&
      !file.name.endsWith(".pdf")
    ) {
      setError("仅支持 .txt / .doc / .docx / .pdf 格式的合同文件，其他格式请先粘贴文本");
      return;
    }
    setFileName(file.name);
    if (file.name.endsWith(".txt")) {
      try {
        const text = await readTextFile(file);
        setContent(text);
      } catch (err: any) {
        setError(err?.message || "读取失败");
      }
    } else {
      setContent(`[已上传文件：${file.name}，请在下方粘贴文件正文以进行 AI 审核]`);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) void handleFile(file);
  };

  const handleSubmit = async () => {
    if (!content.trim()) {
      setError("请先上传合同文件或粘贴合同文本");
      return;
    }
    setReviewing(true);
    setReviewStartedAt(Date.now());
    setError("");
    try {
      const data: ReviewDocumentResponse = await reviewDocument({
        document_type: "contract",
        content: content.trim(),
        title: fileName || "合同审核",
      });
      // 合同原文一并带到审核结果页（逐段展示需要）
      sessionStorage.setItem("lastReviewContent", content.trim());
      navigate("/review/result", {
        state: { result: data, title: fileName || "合同审核结果", content: content.trim() },
      });
    } catch (err: any) {
      setError(err?.message || "审核失败");
      setReviewing(false);
    }
  };

  const clearAll = () => {
    setFileName("");
    setContent("");
    setError("");
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <div className="max-w-5xl space-y-8 pb-20 pt-8">
      <PageHeader
        title="合同审核"
        description="上传合同文件或粘贴合同文本，AI 自动识别风险与条款问题，审核后可在线修改。"
      />

      <section className="rounded-[1.75rem] border border-border bg-card p-6 shadow-sm">
        <div
          onClick={() => fileRef.current?.click()}
          onDrop={handleDrop}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          className={cn(
            "flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-10 text-center transition-colors",
            dragOver
              ? "border-primary bg-primary/5"
              : "border-border bg-secondary/30 hover:border-primary/40 hover:bg-accent/30"
          )}
        >
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/15 bg-primary/5 text-primary">
            <Upload className="h-7 w-7" />
          </div>
          <div className="text-sm font-black text-foreground">点击或拖拽上传合同文件</div>
          <div className="mt-2 text-xs font-bold text-muted-foreground">支持 .txt / .doc / .docx / .pdf</div>
          {fileName && (
            <div className="mt-4 inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2 text-xs font-bold text-foreground shadow-sm">
              <FileText className="h-3.5 w-3.5 text-primary" /> {fileName}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFileName("");
                  setContent("");
                  if (fileRef.current) fileRef.current.value = "";
                }}
                className="ml-1 text-muted-foreground hover:text-rose-600"
              >
                ✕
              </button>
            </div>
          )}
          <input
            ref={fileRef}
            type="file"
            accept={ACCEPT_TYPES}
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
            }}
          />
        </div>

        <div className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-black text-foreground">或直接粘贴合同文本</span>
            <button onClick={clearAll} className="text-xs font-bold text-muted-foreground hover:text-rose-600">
              清空
            </button>
          </div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="请将合同正文粘贴到此处…"
            rows={14}
            className="w-full resize-none rounded-2xl border border-border bg-secondary/30 px-5 py-4 text-sm font-medium leading-relaxed text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-primary/40 focus:ring-2 focus:ring-primary/10"
          />
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-bold text-rose-700">
            <AlertTriangle className="mr-1.5 inline-block h-3.5 w-3.5" /> {error}
          </div>
        )}

        <button
          onClick={() => void handleSubmit()}
          disabled={reviewing || !content.trim()}
          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-5 py-3 text-sm font-black text-primary-foreground shadow-sm transition-all hover:shadow-md disabled:opacity-50"
        >
          {reviewing ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
          {reviewing ? "AI 审核中…" : "开始审核"}
        </button>
        {reviewing && (
          <TaskProgress
            title="AI 审核合同"
            phases={["解析合同文本", "逐条分析条款", "识别风险点", "生成审核报告"]}
            startedAt={reviewStartedAt}
            className="mt-4"
          />
        )}
      </section>
    </div>
  );
}
