import { Link } from "react-router";
import { CheckCircle2, Circle, FileArchive, Package } from "lucide-react";
import { cn } from "../../lib/utils";

/**
 * LitigationStageBar - 诉讼 5 步流水线进度条（跨页面共享）
 *
 * 展示：当前第几步 / 共 5 步 | 本环节产出 | 已就绪 / 未生成 | 查看材料包
 */

export const LITIGATION_STAGES = [
  { step: 1, label: "案件受理", output: "受理记录 + 材料清单" },
  { step: 2, label: "证据管理", output: "证据目录（法院提交格式）" },
  { step: 3, label: "诉讼策略", output: "诉讼策略书" },
  { step: 4, label: "庭审准备", output: "发问 / 质证 / 辩论词 / 法官问答" },
  { step: 5, label: "材料包", output: "庭前材料包 ZIP" },
];

interface LitigationStageBarProps {
  current: number; // 1-5
  ready?: boolean; // 本环节产出是否已就绪
  caseId?: string; // 有案件号时显示“查看材料包”入口
}

export function LitigationStageBar({ current, ready = false, caseId }: LitigationStageBarProps) {
  const stage = LITIGATION_STAGES.find((s) => s.step === current) || LITIGATION_STAGES[0];

  return (
    <div className="rounded-[1.5rem] border border-border bg-card/90 px-6 py-5 shadow-sm">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        {/* 步骤点 */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {LITIGATION_STAGES.map((s, index) => {
            const done = s.step < current;
            const active = s.step === current;
            return (
              <div key={s.step} className="flex items-center">
                {index > 0 && (
                  <div
                    className={cn(
                      "mx-1 h-px w-6 sm:w-10",
                      s.step <= current ? "bg-primary/60" : "bg-border",
                    )}
                  />
                )}
                <div
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide whitespace-nowrap",
                    active && "bg-primary text-primary-foreground shadow-sm",
                    done && "bg-primary/10 text-primary",
                    !active && !done && "bg-muted text-muted-foreground",
                  )}
                >
                  {done ? (
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  ) : active ? (
                    <Circle className="h-3.5 w-3.5 fill-current" />
                  ) : (
                    <span className="flex h-3.5 w-3.5 items-center justify-center text-[9px]">{s.step}</span>
                  )}
                  <span>{s.label}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* 本环节产出 */}
        <div className="flex items-center gap-3 lg:gap-5 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-muted-foreground">本环节产出</span>
            <span className="font-black text-foreground">{stage.output}</span>
          </div>
          <div
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-bold",
              ready ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground",
            )}
          >
            <span className={cn("h-1.5 w-1.5 rounded-full", ready ? "bg-primary" : "bg-muted-foreground/50")} />
            {ready ? "已就绪" : "未生成"}
          </div>
          {caseId && (
            <Link
              to={`/litigation/package?case_id=${caseId}`}
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 font-bold text-foreground transition-colors hover:border-primary/40 hover:bg-accent"
            >
              <Package className="h-3.5 w-3.5" />
              查看材料包
            </Link>
          )}
        </div>
      </div>

      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-700"
          style={{ width: `${(current / 5) * 100}%` }}
        />
      </div>
      <div className="mt-2 text-right text-[10px] font-bold tracking-widest text-muted-foreground">
        第 {current} 步 / 共 5 步
      </div>
    </div>
  );
}

/** 空态：还没有案件时给用户一个引导入口 */
export function EmptyCaseHint() {
  return (
    <div className="flex flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border bg-card/60 px-8 py-16 text-center">
      <FileArchive className="h-10 w-10 text-muted-foreground/50" />
      <div className="mt-4 text-sm font-black text-foreground">还没有可查看的案件</div>
      <div className="mt-2 max-w-sm text-xs font-bold leading-6 text-muted-foreground">
        请先在「案件受理」中创建受理、上传材料并完成归档，归档后的案件会出现在这里。
      </div>
      <Link
        to="/litigation/new"
        className="mt-6 rounded-full bg-primary px-5 py-2 text-xs font-black text-primary-foreground transition-opacity hover:opacity-90"
      >
        去案件受理
      </Link>
    </div>
  );
}
